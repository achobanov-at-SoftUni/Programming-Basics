﻿using System;

namespace LongestNonDecreasingSequence
{
	public class Attempt3
	{
		public Attempt3 ()
		{
		}
	}
}

